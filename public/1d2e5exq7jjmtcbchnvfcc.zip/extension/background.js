const AXIOM_WINDOW_NAME = 'AXIOM_TRADER_WINDOW';
const FM_WINDOW_NAME = 'FM_TRADER_WINDOW';
let dashboardUrlPattern = 'http://192.168.1.21:3000/'; // Default URL

// Function to get the dashboard URL from storage
function updateDashboardUrl() {
  chrome.storage.local.get('dashboardUrl', function(data) {
    if (data.dashboardUrl) {
      dashboardUrlPattern = data.dashboardUrl;
      console.log('Dashboard URL updated to:', dashboardUrlPattern);
    }
  });
}

// Update URL on startup
updateDashboardUrl();

// Listen for changes in storage
chrome.storage.onChanged.addListener(function(changes, namespace) {
  if (changes.dashboardUrl) {
    dashboardUrlPattern = changes.dashboardUrl.newValue;
    console.log('Dashboard URL changed to:', dashboardUrlPattern);
  }
});

// Function to get window.name from a tab via content script
async function getTabWindowName(tabId) {
  try {
    const results = await chrome.scripting.executeScript({
      target: { tabId: tabId },
      func: () => window.name,
    });
    return results[0].result;
  } catch (e) {
    // console.error(`Failed to get window.name for tab ${tabId}:`, e);
    return null;
  }
}

// Periodic check for Axiom windows
setInterval(async () => {
  // 1. Check if dashboard is open
  const dashboardTabs = await chrome.tabs.query({ url: `${dashboardUrlPattern}*` });
  const isDashboardOpen = dashboardTabs.length > 0;

  // 2. Find all Axiom trading windows
  const axiomTabs = await chrome.tabs.query({ url: 'https://axiom.trade/discover*' });
  const fmTabs = await chrome.tabs.query({ url: 'https://chain.fm/home*' });

  let axiomTraderWindows = [];
  for (const tab of axiomTabs) {
    const windowName = await getTabWindowName(tab.id);
    if (windowName === AXIOM_WINDOW_NAME) {
      axiomTraderWindows.push(tab);
    }
  }

  let fmTraderWindows = [];
  for (const tab of fmTabs) {
    const windowName = await getTabWindowName(tab.id);
    if (windowName === FM_WINDOW_NAME) {
      fmTraderWindows.push(tab);
    }
  }

  // 3. Apply closure logic
  if (!isDashboardOpen) {
    // Dashboard is not open, close all Axiom trading windows
    for (const tab of axiomTraderWindows) {
      chrome.tabs.remove(tab.id);
      console.log(`Closed Axiom window (dashboard not open): ${tab.url}`);
    }
    for (const tab of fmTraderWindows) {
      chrome.tabs.remove(tab.id);
      console.log(`Closed Axiom window (dashboard not open): ${tab.url}`);
    }
  } else if (axiomTraderWindows.length > 1) {
    // Dashboard is open, but multiple Axiom trading windows exist, close all
    for (const tab of axiomTraderWindows) {
      chrome.tabs.remove(tab.id);
      console.log(`Closed duplicate Axiom window: ${tab.url}`);
    }
  } else if (fmTraderWindows.length > 1) {
    // Dashboard is open, but multiple Axiom trading windows exist, close all
    for (const tab of fmTraderWindows) {
      chrome.tabs.remove(tab.id);
      console.log(`Closed fmTraderWindows Axiom window: ${tab.url}`);
    }
  }
}, 3000); // Check every 5 seconds


// Function to refresh the dashboard tab
function refreshDashboard() {
  chrome.tabs.query({ url: `${dashboardUrlPattern}*` }, (tabs) => {
    if (tabs.length > 0) {
      chrome.tabs.reload(tabs[0].id);
      console.log('Dashboard refreshed');
    }
  });
}
// Auto-refresh every 30 minutes
setInterval(refreshDashboard, 30 * 60 * 1000);

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'refreshDashboard') {
    refreshDashboard();
  }
});

chrome.runtime.onInstalled.addListener(() => {
  console.log("Axiom Trader Assistant extension installed.");
});